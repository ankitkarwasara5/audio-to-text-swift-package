#Importing necessary libraries
import json
import os
import multiprocessing
from .audio import get_text
import time
import logging

# Configure logging
logging.basicConfig(filename='/Users/ankitkarwasara/Desktop/swiftproject/main_log.log', level=logging.DEBUG,
                    format='%(asctime)s %(levelname)s %(name)s %(message)s')
logger = logging.getLogger(__name__)

ALLOWED_EXTENSIONS = {'wav', 'mp3'}

ALLOWED_LANGLUAGE_CODE = set(["af-ZA","sq-AL","am-ET","ar-DZ","ar-BH","ar-EG","ar-IQ","ar-IL","ar-JO","ar-KW","ar-LB","ar-MR","ar-MA","ar-OM","ar-QA","ar-SA","ar-PS","ar-TN","ar-AE","ar-YE","hy-AM","az-AZ","eu-ES","bn-BD","bn-IN","bs-BA","bg-BG","my-MM","ca-ES","yue-Hant-HK","zh (cmn-Hans-CN)","zh-TW (cmn-Hant-TW)","hr-HR","cs-CZ","da-DK","nl-BE","nl-NL","en-AU","en-CA","en-GH","en-HK","en-IN","en-IE","en-KE","en-NZ","en-NG","en-PK","en-PH","en-SG","en-ZA","en-TZ","en-GB","en-US","et-EE","fil-PH","fi-FI","fr-BE","fr-CA","fr-FR","fr-CH","gl-ES","ka-GE","de-AT","de-DE","de-CH","el-GR","gu-IN","iw-IL","hi-IN","hu-HU","is-IS","id-ID","it-IT","it-CH","ja-JP","jv-ID","kn-IN","kk-KZ","km-KH","rw-RW","ko-KR","lo-LA","lv-LV","lt-LT","mk-MK","ms-MY","ml-IN","mr-IN","mn-MN","ne-NP","no-NO","fa-IR","pl-PL","pt-BR","pt-PT","pa-Guru-IN","ro-RO","ru-RU","sr-RS","si-LK","sk-SK","sl-SI","st-ZA","es-AR","es-BO","es-CL","es-CO","es-CR","es-DO","es-EC","es-SV","es-GT","es-HN","es-MX","es-NI","es-PA","es-PY","es-PE","es-PR","es-ES","es-US","es-UY","es-VE","su-ID","sw-KE","sw-TZ","ss-Latn-ZA","sv-SE","ta-IN","ta-MY","ta-SG","ta-LK","te-IN","th-TH","ts-ZA","tn-Latn-ZA","tr-TR","uk-UA","ur-IN","ur-PK","uz-UZ","ve-ZA","vi-VN","xh-ZA","zu-ZA"])

class InvalidFileExtensionError(Exception):
    """Exception raised for errors in the input file extension.

    Attributes:
        filename -- input filename which caused the error
        message -- explanation of the error
    """

    def __init__(self, filename, message="File extension is not allowed"):
        self.filename = filename
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f'{self.filename} -> {self.message}'

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def call_audio_to_text(filename, enable_speaker_diarization, diarization_speaker_count, language_code):
	if not enable_speaker_diarization:
		enable_speaker_diarization = True
	return get_text(filename, enable_speaker_diarization, diarization_speaker_count, language_code)


def main(filenames,enable_speaker_diarizations, diarization_speaker_counts, language_codes):
	print("main function is called")

	if not isinstance(filenames, list) or not isinstance(enable_speaker_diarizations, list) or not isinstance(diarization_speaker_counts, list) or not isinstance(language_codes, list):
		raise TypeError("Only List values allowed for main function")

	if not (len(filenames) == len(enable_speaker_diarizations) == len(diarization_speaker_counts) == len(language_codes)):
		raise ValueError("All lists length should be same")

	# Checking file names
	for filename in filenames:
		if not isinstance(filename, str):
			raise TypeError("Only String values allowed inside filenames")
		if not allowed_file(filename):
			raise InvalidFileExtensionError(filename, f"This file extension is not supported only {ALLOWED_EXTENSIONS} supported")
		if not os.path.exists(filename):
			raise FileNotFoundError(f"The file '{filename}' does not exist.")
	# Checking other parameters for code
	for enable_speaker_diarization, diarization_speaker_count, language_code in zip(enable_speaker_diarizations,diarization_speaker_counts,language_codes):
		if not isinstance(enable_speaker_diarization, bool):
			raise ValueError("Only Boolean values allowed inside enable_speaker_diarizations")
		if not isinstance(diarization_speaker_count, int):
			raise ValueError("Only Int values allowed inside diarization_speaker_counts")
		if not isinstance(language_code, str):
			raise TypeError("Only String values allowed inside language_codes")
		if language_code not in ALLOWED_LANGLUAGE_CODE:
			raise InvalidFileExtensionError(language_code, f"This Language is not supported only {ALLOWED_LANGLUAGE_CODE} supported")
		if diarization_speaker_count < 0:
			raise ValueError("Only Positive Int values allowed inside diarization_speaker_counts")
		if  not enable_speaker_diarization and diarization_speaker_count > 1:
			raise ValueError("If enable_speaker_diarization is False then diarization_speaker_count should be 1")

	multiprocessing.freeze_support()

	# Determine the number of CPUs available
	num_cpus = multiprocessing.cpu_count()
	# Creating a pool of worker processes, one for each CPU
	with multiprocessing.Pool(processes=num_cpus) as pool:
		# Zip the arguments together so each iteration provides a tuple of arguments
		args = zip(filenames, enable_speaker_diarizations, diarization_speaker_counts, language_codes)
		# Map call_audio_to_text function to the arguments
		results = pool.starmap(call_audio_to_text, args)

		output = {}
		for i, text in enumerate(results):
			output[filenames[i]] = text

		return output
	

if __name__ == '__main__':
	try:
		logger.info("Processing started")
		result = main(["client/sample.mp3", "client/conversation_audio.wav"], [False, True], [1, 2], ["en-GB", "en-IN"])
		logger.info(f"Processing completed: {result}")
	except Exception as e:
		logger.error(f"Main execution error: {e}")







