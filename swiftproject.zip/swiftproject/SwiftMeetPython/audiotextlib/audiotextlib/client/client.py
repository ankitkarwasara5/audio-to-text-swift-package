from Audio_text_lib import main

if __name__ == "__main__":
	main(["sample.wav", "conversation_audio.wav"],[False ,True],[1,2],["en-GB","en-IN"])