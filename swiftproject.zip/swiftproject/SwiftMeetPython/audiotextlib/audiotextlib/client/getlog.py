import requests

# URL of the Flask server endpoint that provides the log file
URL = "https://delfy-speec-to-text-tools-stag-6207c71d50a5.herokuapp.com/get_logs"

response = requests.get(URL)

# Ensure the request was successful
if response.status_code == 200:
    # Save the content to a local file
    with open('downloaded_logs.zip', 'wb') as file:
        file.write(response.content)
    print("Log files downloaded successfully as downloaded_logs.zip!")
else:
    print(f"Failed to download the log files. Server responded with status code: {response.status_code}")
