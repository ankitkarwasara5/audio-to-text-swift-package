import os
import json
import subprocess
from google.cloud import speech_v1p1beta1 as speech
from google.oauth2.service_account import Credentials
import requests
import logging

# Configure logging
logging.basicConfig(filename='/Users/ankitkarwasara/Desktop/swiftproject/audio_log.log', level=logging.DEBUG,
                    format='%(asctime)s %(levelname)s %(name)s %(message)s')
logger = logging.getLogger(__name__)

def get_text(filename, enable_speaker_diarization, diarization_speaker_count, language_code):
    
    try:
        logger.info(f"Processing file: {filename}")
        if filename.rsplit('.', 1)[1].lower() == "mp3":
            logger.info(f"Converting {filename} to WAV format")
            convert_mp3_to_wav(filename, filename.rsplit('.', 1)[0] + ".wav")
            filename = filename.rsplit('.', 1)[0] + ".wav"

        logger.info("Loading Google Cloud credentials")
        credentials_raw = os.environ.get("GOOGLE_CLOUD_CREDENTIALS")
        if not credentials_raw:
            raise RuntimeError("Google Cloud credentials not found")

        credentials_json = json.loads(credentials_raw)
        credentials = Credentials.from_service_account_info(credentials_json)

        client = speech.SpeechClient(credentials=credentials)
        logger.info(f"Reading file: {filename}")
        with open(filename, "rb") as audio_file:
            content = audio_file.read()

        audio = speech.RecognitionAudio(content=content)
        encoding = get_audio_encoding(filename)

        config = speech.RecognitionConfig(
            encoding=encoding,
            language_code=language_code,
            enable_speaker_diarization=enable_speaker_diarization,
            diarization_speaker_count=diarization_speaker_count
        )

        response = client.recognize(config=config, audio=audio)

        prev_speaker = 0
        output = []
        for result in response.results[1].alternatives[0].words:
            current_word = result.word
            current_speaker = result.speaker_tag
            if current_speaker != prev_speaker:
                output.append({f"speaker_{current_speaker}": current_word})
                prev_speaker = current_speaker
            else:
                output[len(output)-1][f"speaker_{current_speaker}"] += f" {current_word}"
                
        return output

    except FileNotFoundError:
        return {filename: "File not found"}
    except json.JSONDecodeError:
        return {filename: "Invalid credentials format"}
    except Exception as e:
        error_message = f"Error processing file: {str(e)}"
        logger.error(f"Error occurred: {e}")
        return {filename: error_message}
# def get_text(filename, enable_speaker_diarization, diarization_speaker_count, language_code):
#     """Transcribe the given audio file with speaker diarization."""

#     try:
#         if filename.rsplit('.', 1)[1].lower() == "mp3":
#             convert_mp3_to_wav(filename,filename.rsplit('.', 1)[0]+".wav")
#             filename = filename.rsplit('.', 1)[0]+".wav"


#         # Get credentials from environment variable
#         credentials_raw = os.environ.get("GOOGLE_CLOUD_CREDENTIALS")
#         credentials_json = json.loads(credentials_raw)
#         credentials = Credentials.from_service_account_info(credentials_json)

#         client = speech.SpeechClient(credentials=credentials)

#         with open(filename, "rb") as audio_file:
#             content = audio_file.read()

#         audio = speech.RecognitionAudio(content=content)

#         encoding = get_audio_encoding(filename)

#         config = speech.RecognitionConfig(
#             encoding=encoding,
#             #sample_rate_hertz=16000,
#             language_code=language_code,
#             enable_speaker_diarization=enable_speaker_diarization,
#             diarization_speaker_count=diarization_speaker_count,  # Adjust this based on the number of speakers you expect
#         )

#         response = client.recognize(config=config, audio=audio)

#         prev_speaker = 0
#         output = []
#         for result in response.results[1].alternatives[0].words:
#             current_word = result.word
#             current_speaker = result.speaker_tag
#             if current_speaker != prev_speaker:
#                 output.append({f"speaker:-{current_speaker}": current_word})
#                 prev_speaker = current_speaker
#             else:
#                 output[len(output)-1][f"speaker:-{current_speaker}"] += f" {current_word}"

#         return output

#     except Exception as e:
#         return "Error occured"


def convert_mp3_to_wav(mp3_file_path, wav_file_path):
    cmd = [
        'ffmpeg',
        '-y',
        '-i', mp3_file_path,
        '-acodec', 'pcm_s16le',  # Set audio codec to pcm_s16le (Linear PCM)
        '-ac', '1',  # Set number of audio channels to 1 (mono)
        '-ar', '16000',  # Set audio sample rate to 16 kHz
        wav_file_path
    ]
    output = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)

def get_audio_encoding(file_path):
    cmd = [
        'ffprobe',
        '-v', 'quiet',
        '-print_format', 'json',
        '-show_streams',
        file_path
    ]

    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    output = json.loads(result.stdout)
    logger.debug(output.stdout.decode())
    logger.error(output.stderr.decode())

    # Fetching the codec name and bit depth
    codec_name = output['streams'][0]['codec_name']
    if 'bits_per_raw_sample' in output['streams'][0]:
        bit_depth = int(output['streams'][0]['bits_per_raw_sample'])
    else:
        bit_depth = None

    if codec_name == 'pcm_s16le':
        return speech.RecognitionConfig.AudioEncoding.LINEAR16
    elif codec_name == 'flac':
        # FLAC may be 16 or 24 bit
        return speech.RecognitionConfig.AudioEncoding.FLAC
    elif codec_name == 'mulaw':
        return speech.RecognitionConfig.AudioEncoding.MULAW
    elif codec_name == 'amr_nb':  # NB: Narrowband
        return speech.RecognitionConfig.AudioEncoding.AMR
    elif codec_name == 'amr_wb':  # WB: Wideband
        return speech.RecognitionConfig.AudioEncoding.AMR_WB
    else:
        return speech.RecognitionConfig.AudioEncoding.LINEAR16