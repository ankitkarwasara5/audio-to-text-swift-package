import Vapor
import PythonKit

struct UploadFormData: Content {
    var file: File
    var password: String?
}

func routes(_ app: Application) throws {
    // Function to save the uploaded file
    func saveFile(filename: String, data: Data) throws -> String {
        let workDir = app.directory.workingDirectory
        let filePath = workDir + "Uploads/\(filename)"
        try data.write(to: URL(fileURLWithPath: filePath))
        return filePath
    }

        // Initialize and import Python environment and modules here
        let sys = Python.import("sys")
        let os = Python.import("os")
        os.chdir("audiotextlib") // Adjust this path as needed
        let cwd = os.getcwd()
        sys.path.append(cwd)
        let audioTextLib = Python.import("audiotextlib")
        Logger.shared.log("Imported audio_text_lib")

    // Route for serving the upload page
    app.get { req -> EventLoopFuture<View> in
        Logger.shared.log("Serving upload.html")
        return req.view.render("upload.html")
    }

    // Route for processing audio files
    app.post("process-audio") { req -> EventLoopFuture<String> in
        Logger.shared.log("Received request to process audio file")

        let formData = try req.content.decode(UploadFormData.self)
        guard let data = formData.file.data.getData(at: 0, length: formData.file.data.readableBytes) else {
            Logger.shared.log("Failed to read audio file data")
            throw Abort(.internalServerError, reason: "Failed to read audio file data.")
        }

        let filePath = try saveFile(filename: formData.file.filename, data: data)
        Logger.shared.log("Saved file at path: \(filePath)")

        let filePathPython = PythonObject(filePath)
        let fileNames = Python.list([filePathPython])
        let enableSpeakerDiarizations = Python.list([true]) 
        let diarizationSpeakerCounts = Python.list([2])
        let languageCodes = Python.list(["en-US"])

        // Call your Python function here
        let result = audioTextLib.main(fileNames, enableSpeakerDiarizations, diarizationSpeakerCounts, languageCodes)
        Logger.shared.log("Python function get_text called")

        if let resultDict = Dictionary<String, String>(result), let errorMessage = resultDict[filePath] {
            Logger.shared.log("Error from Python script: \(errorMessage)")
            throw Abort(.internalServerError, reason: errorMessage)
        } else if let resultString = String(result) {
            Logger.shared.log("Processing completed successfully: \(resultString)")
            return req.eventLoop.makeSucceededFuture(resultString)
        } else {
            Logger.shared.log("Unknown error occurred")
            throw Abort(.internalServerError, reason: "Unknown error occurred in processing")
        }
    }
}
