import Foundation

class Logger {
    static let shared = Logger()

    private var fileHandle: FileHandle?

    init() {
        let fileManager = FileManager.default
        let logFilePath = "/Users/ankitkarwasara/Desktop/swiftproject/logfile.txt"

        if !fileManager.fileExists(atPath: logFilePath) {
            fileManager.createFile(atPath: logFilePath, contents: nil, attributes: nil)
        }

        do {
            fileHandle = try FileHandle(forWritingTo: URL(fileURLWithPath: logFilePath))
            fileHandle?.seekToEndOfFile()
        } catch {
            print("Unable to open file handle for logging: \(error)")
        }
    }

    deinit {
        fileHandle?.closeFile()
    }

    func log(_ message: String) {
        guard let fileHandle = fileHandle else { return }

        if let data = "[\(Date())] \(message)\n".data(using: .utf8) {
            fileHandle.write(data)
        }
    }
}
