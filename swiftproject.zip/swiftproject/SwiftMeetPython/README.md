# PDF to Text
This takes a PDF file and extract text from it.

## Python Library
Python Library name is `pdf_lib`.

### input
You should import main function that can take upto two arguments. First one is python-bytes `pythonData` and second one is password (Optional) `password`

### output
The output will be a json like `{"sucess":True/False, "text":"text/error"}`

## Test cases
3 files present in the `pdf_lib` folder. 
`sample.pdf` :- Regular PDF File - should work with no password - wrong password
`sample_1.pdf` :- Text extraction not allowed - should work with no password - wrong password
`sample_2.pdf` :- Password protected file- Only works with correct password else give error saying incorrect password. Correct password is `sample`